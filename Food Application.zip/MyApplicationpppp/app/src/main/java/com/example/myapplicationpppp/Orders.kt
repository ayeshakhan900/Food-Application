package com.example.myapplicationpppp

import android.content.Intent
import android.content.Intent.getIntent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class Orders : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_orders)
        var count=findViewById<TextView>(R.id.counterr)
        var pri=findViewById<TextView>(R.id.price)
        var orders=findViewById<Button>(R.id.place)
        var addres=findViewById<EditText>(R.id.address)
      //  var intent=getIntent()

        var counter=intent.getStringExtra("count")
         var pricee=intent.getStringExtra("price")
      //  Toast.makeText(this,"ORder counter is"+counter.toString(),Toast.LENGTH_LONG).show()

        count.text=""+counter
        pri.text="Price is: "+pricee

         orders.setOnClickListener{
             var neworder: Details = Details()
             neworder.add(addres.text.toString(),counter.toString(),pricee.toString())
             val database = Firebase.database
             val db = database.getReference("FoodOrder")
             db.child(""+count.text.toString()).setValue(neworder)
             
                 .addOnCompleteListener(this) {

                         task ->
                     if (task.isSuccessful) {
                         Toast.makeText(this, "Order placed Successfull", Toast.LENGTH_SHORT).show()

                     } else {
                         Toast.makeText(
                             this,
                             "Unsuccesful" + task.exception.toString(),
                             Toast.LENGTH_SHORT
                         ).show()


                     }
                 }
         }

    }
}