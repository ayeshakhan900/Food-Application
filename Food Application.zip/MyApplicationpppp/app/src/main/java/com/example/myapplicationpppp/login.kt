package com.example.myapplicationpppp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class login : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        var email = findViewById<EditText>(R.id.email1)
        var pass = findViewById<EditText>(R.id.pass1)
        var btn_signin = findViewById<Button>(R.id.signin1)
        btn_signin.setOnClickListener {
            var auth: FirebaseAuth = Firebase.auth
            auth.signInWithEmailAndPassword(email.text.toString(), pass.text.toString())
                .addOnCompleteListener(this) {

                        task ->
                    if (task.isSuccessful) {
                        Toast.makeText(this, "SingIn Successfull", Toast.LENGTH_SHORT).show()
                        startActivity(Intent(this, FoodOrdering::class.java))

                    } else {
                        Toast.makeText(
                            this,
                            "SignIN Unsuccesful",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
        }
    }
}