package com.example.myapplicationpppp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class FoodOrdering : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_food_ordering)
        var btn_pizza=findViewById<Button>(R.id.pizza)
        var btn_burger=findViewById<Button>(R.id.burger)
        var btn_drink=findViewById<Button>(R.id.drinks)
        var btn_order=findViewById<Button>(R.id.order)

        btn_pizza.setOnClickListener {
            startActivity(Intent(this,Pizza::class.java))
        }
        btn_burger.setOnClickListener {
            startActivity(Intent(this,Burger::class.java))
        }
        btn_drink.setOnClickListener {
            startActivity(Intent(this,Drink::class.java))
        }
        btn_order.setOnClickListener {
            startActivity(Intent(this,Orders::class.java))
        }
    }
}