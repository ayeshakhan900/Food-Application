package com.example.myapplicationpppp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class Signup : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)
        var btn_sign = findViewById<Button>(R.id.signup1)
        var btn_back = findViewById<Button>(R.id.back)
        var mail = findViewById<EditText>(R.id.email)
        var pas = findViewById<EditText>(R.id.pass)

        btn_back.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }
        btn_sign.setOnClickListener {
            var auth: FirebaseAuth = Firebase.auth
            auth.createUserWithEmailAndPassword(mail.text.toString(), pas.text.toString())
                .addOnCompleteListener(this) {

                        task ->
                    if (task.isSuccessful) {
                        Toast.makeText(this, "Singup Successfull", Toast.LENGTH_SHORT).show()

                    } else {
                        Toast.makeText(
                            this,
                            "Signup Unsuccesful" + task.exception.toString(),
                            Toast.LENGTH_SHORT
                        ).show()

                        startActivity(Intent(this, MainActivity::class.java))

                    }

                }
        }
    }}