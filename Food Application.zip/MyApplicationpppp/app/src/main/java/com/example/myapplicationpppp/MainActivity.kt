package com.example.myapplicationpppp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Window
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var btn_login=findViewById<Button>(R.id.login)
        var btn_sign=findViewById<Button>(R.id.signup)

        btn_sign.setOnClickListener {
            startActivity(Intent(this,Signup::class.java))
        }
        btn_login.setOnClickListener {
            startActivity(Intent(this,login::class.java))
        }

       // requestWindowFeature(Window.FEATURE_NO_TITLE);//will hide the title
      getSupportActionBar()?.hide() //hide the title bar
    }
}