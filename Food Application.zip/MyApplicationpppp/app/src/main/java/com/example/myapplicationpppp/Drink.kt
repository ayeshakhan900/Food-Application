package com.example.myapplicationpppp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class Drink : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_drink)
        var bt1=findViewById<Button>(R.id.b1)
        var bt2=findViewById<Button>(R.id.b2)
        var bt3=findViewById<Button>(R.id.b3)
        var bt4=findViewById<Button>(R.id.b4)
        var ordr=findViewById<Button>(R.id.order3)
        var counter = 0
        var price=0
        bt1.setOnClickListener{
            Toast.makeText(this, "Item has added", Toast.LENGTH_SHORT).show()
            price+=100
            counter++
        }
        bt2.setOnClickListener{
            Toast.makeText(this, "Item has added", Toast.LENGTH_SHORT).show()
            price+=120
            counter++
        }
        bt3.setOnClickListener{
            Toast.makeText(this, "Item has added", Toast.LENGTH_SHORT).show()
            price+=50
            counter++
        }
        bt4.setOnClickListener{
            Toast.makeText(this, "Item has added", Toast.LENGTH_SHORT).show()
            price+=100
            counter++
        }
        ordr.setOnClickListener {
            startActivity(
                Intent(this,Orders::class.java).putExtra("count",counter.toString()).putExtra("price",
                price.toString()))
        }

    }
}