package com.example.myapplicationpppp

class Details {
    var address:String?=null
    var Price:String?=null
    var count:String?=null
    fun add(ad:String,p:String,c:String)
    {
        address=ad
        Price=p
        count=c
    }
}