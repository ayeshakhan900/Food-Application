package com.example.myapplicationpppp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast

class Pizza : AppCompatActivity() {
    private  var counter:Int=0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pizza)
        var btn_medium = findViewById<Button>(R.id.medium)
        var btn_large = findViewById<Button>(R.id.large)
        var btn_small = findViewById<Button>(R.id.small)
        var btn_order = findViewById<Button>(R.id.order1)
        var counter = 0
        var price=0
        btn_medium.setOnClickListener {
            Toast.makeText(this, "Item has added", Toast.LENGTH_SHORT).show()
            counter++
            price+=1000
        }
        btn_large.setOnClickListener {
            Toast.makeText(this, "Item has added", Toast.LENGTH_SHORT).show()
            price+=2000
            counter++
        }
        btn_small.setOnClickListener {
            Toast.makeText(this, "Item has added", Toast.LENGTH_SHORT).show()
            price+=500
            counter++
        }

        btn_order.setOnClickListener {
           // Toast.makeText(this, "Counter is "+counter, Toast.LENGTH_SHORT).show()
            startActivity(Intent(this,Orders::class.java).putExtra("count",counter.toString()).putExtra("price",
            price.toString()))
        }
    }



    }
