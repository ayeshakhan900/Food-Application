package com.example.myapplicationpppp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class Burger : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_burger)
        var b1=findViewById<Button>(R.id.btn1)
        var b2=findViewById<Button>(R.id.btn2)
        var b3=findViewById<Button>(R.id.btn3)
        var b4=findViewById<Button>(R.id.btn4)
        var btn_order2=findViewById<Button>(R.id.order2)
        var counter=0
        var price=0
        b1.setOnClickListener{
            Toast.makeText(this, "Item has added", Toast.LENGTH_SHORT).show()
            counter++
            price+=100
        }
        b2.setOnClickListener{
            Toast.makeText(this, "Item has added", Toast.LENGTH_SHORT).show()
            counter++
            price+=150
        }
        b3.setOnClickListener{
            Toast.makeText(this, "Item has added", Toast.LENGTH_SHORT).show()
            counter++
            price+=599
        }
        b4.setOnClickListener{
            Toast.makeText(this, "Item has added", Toast.LENGTH_SHORT).show()
            counter++
            price+=799
        }
        btn_order2.setOnClickListener {
            // Toast.makeText(this, "Counter is "+counter, Toast.LENGTH_SHORT).show()
            startActivity(
                Intent(this,Orders::class.java).putExtra("count",counter.toString()).putExtra("price",
                price.toString()))
        }
    }
}